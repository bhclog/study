

#include <iostream>


int main(int argc, char** argv)
{
    std::cout << "bhc test" << std::endl;
    return 0;
}