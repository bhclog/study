#include <mylib.hpp>

int main() {
	MyLib mylib;
	mylib.PrintMessage("HELLO CONAN-WAF TEST!");
	return 0;
}
