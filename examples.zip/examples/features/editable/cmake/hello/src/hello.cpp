#include "say.h"

int main() {
    say();
}