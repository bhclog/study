from conans import ConanFile, tools

required_conan_version = ">=1.28"

class PkgaConan(ConanFile):
    pass
