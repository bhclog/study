#pragma once
#include <iostream>

inline void helloA(){
  std::cout << "HelloA %V% %BT%\n";
}
