#!/bin/bash

set -ex

python build.py
