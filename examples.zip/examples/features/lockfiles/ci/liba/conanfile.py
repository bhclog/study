from conans import ConanFile, tools

required_conan_version = ">=1.28.0"

class PkgaConan(ConanFile):
    settings = "build_type"
