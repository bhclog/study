#include <iostream>
#include "hello.h"

int main() {
    hello();
}
