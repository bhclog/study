#!/bin/bash

conan create pyreq user/channel
conan create consumer user/channel
