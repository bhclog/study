#pragma once
#include <string>

void say(std::string msg);