#pragma once

void hello();