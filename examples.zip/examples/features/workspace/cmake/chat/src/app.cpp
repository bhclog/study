#include "chat.h"

int main(){
    chat();
}