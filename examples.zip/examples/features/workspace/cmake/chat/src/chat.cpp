#include "hello.h"

void chat(){
    hello();
    hello();
    hello();
}