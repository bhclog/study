#pragma once

void chat();