#include <iostream>
#include "bye.h"

int main() {
    bye();
}
