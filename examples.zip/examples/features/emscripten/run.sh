#!/usr/bin/env bash

source activate.sh
emrun ./bin/conan-hello-emscripten.html
